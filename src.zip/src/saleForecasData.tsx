import React, { useEffect, useState } from "react";
import { Container, Row, Col } from "react-bootstrap";


interface SaleForeCastUser {
    OnwerName: string;
    OnwerRole: string;
    SubmisionStatus: string;
    DueDate: Date;
    submisionDate: any;
    SubmittedBy: string;
    RemainingDays: number;
    id: number;

}



function SaleForeCast(props: any) {

    const [SaleForeCast, setSaleForeCast] = useState<SaleForeCastUser[]>([]);

    // const [isColorChange,setColorChange] = React.useState(false);

    const formatDate = (dt: Date) => {

        return PadNum(dt.getDate()) + "-" + PadNum(dt.getMonth() + 1) + "-" + dt.getFullYear();
        // return dt.getDate() + "-" + padNum(dt.getMonth()+1) + "-" + dt.getFullYear();
        //return "2023-03-15"
    }

    const PadNum = (val: number) => {
        return val < 10 ? "0" + val : val;
    }

    useEffect(() => {

        fetch('/Database/saleForCast.json', {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }
        ).then(function (response) {
            // console.log(response)
            return response.json();
        })
            .then((BusinessUnitsUsers) => {
                let BuItems = BusinessUnitsUsers.data.filter(
                    (bItems: any) => bItems.BusinessUnit === props.ocData.selectedBU.split('.')[1].trim()
                );

                if (BuItems.length) {

                    let TempTempBaselineUser: any = [];
                    BuItems[0].SaleForeCast.forEach((element: any, index: any) => {


                        let BaselineUser: SaleForeCastUser = {
                            OnwerName: element.Owner,
                            OnwerRole: element.Role,
                            SubmisionStatus: "Pending for Authorisation by the Owner",
                            DueDate: getBaselineDate(),
                            submisionDate: null,
                            SubmittedBy: "",
                            RemainingDays: 2,
                            id: index

                        }
                        TempTempBaselineUser.push(BaselineUser);
                    });

                    setSaleForeCast(TempTempBaselineUser);
                }

                // console.log(BusinessUnitsUsers);

            });

    }, [])


    const getBaselineDate = () => {
        var dt = new Date();
        dt.setDate(dt.getDate() + 2)
        return dt;
    }


    const OnSaleForCastSubmit = (bUser: SaleForeCastUser) => {
        console.log(bUser);
        bUser.SubmittedBy = 'Lokesh Girhepunje';
        bUser.submisionDate = formatDate(new Date());
        bUser.SubmisionStatus = "Completed";
        bUser.RemainingDays = 0;

       // let allCompleted = true;
    //     Baseline.forEach((item.BaselineUser)=> {
    //     if (item.SubmisionStatus === "Pending for Authorisation by the Owner") {
    //        allCompleted = false;
    //     }
    // })
    // if (allCompleted) {
    //     props.isBaselineCompleted(allCompleted)
    // }

    let allComleted= true

    // Baseline.map((item:BaselineUser)=>{

    //     if(item.SubmisionStatus==="Pending for Authorisation by the Owner")
    //     {
    //         allComleted=false
    //     }
    // })

    // if(allComleted)
    // {
    //     props.isBaselineCompleted(allComleted)
    // }



    let pendingBUsers = SaleForeCast.filter(item=>item.SubmisionStatus==="Pending for Authorisation by the Owner");
    if(pendingBUsers.length===0)
    {
        props.isaleForeCastCompleted(true);
    }

        setSaleForeCast((prevSaleForeCast) => {

            const newSaleForeCast = [...prevSaleForeCast]

            const index = newSaleForeCast.findIndex((user: any) => user.id === bUser.id)

            if (index >= 0) {
                newSaleForeCast.splice(index, 1, bUser)

            }
            else {
                newSaleForeCast.push(bUser)
            }
            return newSaleForeCast;
        });


        // const isColorChange = (bUser:BaselineUser)=>{
        //     if(bUser.SubmisionStatus==="Pending for Authorisation by the Owner")
        //     {
        //         bUser.SubmisionStatus="green"
        //     }
        //     else
        //     {
        //         bUser.SubmisionStatus="Red"
        //      }
        // }
        

}





return (
    <>
        <center style={{ padding: '0px 0px 25px 0px' }}> <h1 style={{ color: 'green', }}>Baseline Data</h1></center>
        <div>
            <Container fluid style={{ backgroundColor: '#f2f2f2', border: '1px solid #E8E8E8', padding: '40px 10px 40px 10px', borderRadius: '10px', boxShadow: ' 2px 1px 3px 1px #888888' }}>

                <Row>

                    <Col as={Col} xs={12} md={1}>

                        <span>Title :</span>
                    </Col>
                    <Col as={Col} xs={12} md={3}>
                        <label><b>{props.ocData.ocTitle}</b></label>

                    </Col>
                    <Col as={Col} xs={12} md={1}>
                        <span>Company : </span>

                    </Col>
                    <Col as={Col} xs={12} md={3}>
                        <label><b>{props.ocData.selectedCompany}</b></label>

                    </Col>
                    <Col as={Col} xs={12} md={1}>
                        <span>Business Unit:</span>

                    </Col>
                    <Col as={Col} xs={12} md={3}>

                        <label><b>{props.ocData.selectedBU}</b></label>
                    </Col>
                </Row>
                <br />
                <Row>

                    <Col as={Col} xs={12} md={1}>

                        <span>Country :</span>
                    </Col>
                    <Col as={Col} xs={12} md={3}>
                        <label><b>{props.ocData.selectedCountry}</b></label>

                    </Col>
                    <Col as={Col} xs={12} md={1}>
                        <span>Start Date :</span>

                    </Col>
                    <Col as={Col} xs={12} md={3}>
                        <label><b>{formatDate(new Date(props.ocData.selectedStartDAte))}</b></label>
                    </Col>
                    <Col as={Col} xs={12} md={1}>
                        <span>End Date :</span>

                    </Col>
                    <Col as={Col} xs={12} md={3}>

                        <label><b>{formatDate(new Date(props.ocData.selectedEndDate))}</b></label>
                    </Col>
                </Row>


            </Container >

            <br />

            <Container fluid style={{ backgroundColor: '#f2f2f2', border: '1px solid #E8E8E8', padding: '10px 0px 0px 10px', borderRadius: '10px', boxShadow: ' 3px 1px 3px 1px #888888', fontSize: "15px" }}>
                <Row>
                    <Col as={Col} xs={12} md={1}>
                        <p><b>Owner Name</b></p>
                    </Col>
                    <Col as={Col} xs={12} md={1}>
                        <p> <b>Owner Role</b></p>
                    </Col>
                    <Col as={Col} xs={12} md={1}>
                        <p><b>Template Link</b></p>
                    </Col>
                    <Col as={Col} xs={12} md={2}>
                        <p><b>Submission Status</b> </p>
                    </Col>
                    <Col as={Col} xs={12} md={1}>
                        <p><b>Due Date</b></p>
                    </Col>
                    <Col as={Col} xs={12} md={2}>
                        <p> <b>Submission Date</b></p>
                    </Col>
                    <Col as={Col} xs={12} md={2}>
                        <p><b>Submitted by</b>
                        </p>
                    </Col>
                    <Col as={Col} xs={12} md={1}>
                        <p><b>Remaining days</b></p>
                    </Col>
                    <Col as={Col} xs={12} md={1}>
                        <p><b>Action</b></p>
                    </Col>

                </Row>
            </Container>


            <br />

            <Container fluid style={{ backgroundColor: '#f2f2f2', border: '1px solid #E8E8E8', padding: '20px 0px 15px 10px', borderRadius: '10px', boxShadow: ' 3px 1px 3px 1px #888888', fontSize: "15px" }}>
                <Row>
                    {
                        SaleForeCast.map((bUser: SaleForeCastUser) => {
                            return (
                                <>
                                    <Col as={Col} xs={12} md={1}>
                                        <p><b>{bUser.OnwerName}</b></p>
                                    </Col>

                                    <Col as={Col} xs={12} md={1}>
                                        <p> {bUser.OnwerRole}</p>
                                    </Col>
                                    <Col as={Col} xs={12} md={1}>
                                        <p></p>
                                    </Col>
                                    <Col as={Col} xs={12} md={2}>
                                        <p style={{ color: '#CFAD22 ' }}><b>{bUser.SubmisionStatus}</b></p>


                                    </Col>
                                    <Col as={Col} xs={12} md={1}>
                                        <p>{formatDate(bUser.DueDate)}</p>
                                    </Col>
                                    <Col as={Col} xs={12} md={2}>
                                        <p> {bUser.submisionDate}
                                        


                                        </p>
                                    </Col>
                                    <Col as={Col} xs={12} md={2}>
                                        <p><b>{bUser.SubmittedBy}</b>
                                        </p>
                                    </Col>
                                    <Col as={Col} xs={12} md={1}>
                                        <p>{bUser.RemainingDays}</p>
                                    </Col>
                                    <Col as={Col} xs={12} md={1} style={{ 'padding': '10px' }}>
                                        <button type="button" className="btn btn-success" disabled={bUser.SubmisionStatus === 'Completed'} onClick={() => { OnSaleForCastSubmit(bUser) }}>Submit</button>
                                    </Col>

                                </>
                            )
                        })
                    }
                </Row>

            </Container>


        </div>

    </>
)
}
export default SaleForeCast;

function user(value: never, index: number, obj: never[]): unknown {
    throw new Error("Function not implemented.");
}

