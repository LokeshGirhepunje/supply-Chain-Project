import React from 'react';

import './App.css';
import SupplyStages from './OrderChainCycle';
import Header from './Header';

import { HashRouter, Routes, Route } from 'react-router-dom';
import Dashboard from './dashboard';
import { Steps } from 'rsuite';
import OCSteps from './Steps';

function App() {
  return (
    <>

          
            

            <HashRouter>
            <Header></Header>
           
            <Routes>
              <Route path="/" element={<Dashboard></Dashboard>}></Route>
              <Route path="/home" element={<Dashboard></Dashboard>}></Route>
              <Route path="/newOrderCycle" element={<OCSteps></OCSteps> }></Route>
             
               </Routes>
             </HashRouter>
   </>
  );
}

export default App;
