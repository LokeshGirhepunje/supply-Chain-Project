import React from "react";
import { Navbar, Container, Nav, Form } from "react-bootstrap";
import { AiOutlineHome } from "react-icons/ai";
import Logo from './Images/logo.png'
import { HeaderProps } from "rsuite";
import { NavLink } from "react-router-dom";





class Header extends React.Component<HeaderProps,any> 
{
    render(): React.ReactNode {
        return(
            <>
            <Navbar bg="light" expand="lg" sticky="top" style={{  boxShadow:' 2px 1px 3px 1px #888888', margin:'2px 10px 0 10px',borderRadius:'10px'}}>
                    <Container fluid>
                        <Navbar.Brand href="#"><img src={Logo} alt="" width={90} height={60}/>
                        
                        </Navbar.Brand>
                        <Navbar.Toggle aria-controls="navbarScroll" />
                        <Navbar.Collapse id="navbarScroll">
                        <Nav
                            className="me-auto my-2 my-lg-0"
                            style={{ maxHeight: '100px' }}
                            navbarScroll>

                                <NavLink to={"/home"} style={{textDecoration:"none",color:"black",fontSize:"15px"}}>Home</NavLink>&nbsp; &nbsp; &nbsp;
                                <NavLink to={"/newOrderCycle"} style={{textDecoration:"none",color:"black",fontSize:"15px"}}>New-Order-Cycle</NavLink>


                           {/* <NavLink><a href="/home">Home</a></NavLink>
                           <NavLink><a href="/newOrderCycle" style={{textDecoration:"none",color:"black"}}>New Order Cycle</a></NavLink>
                           */}
                        </Nav>
                        <Form className="d-flex">
                          <p> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;    Welcome, <br /> Lokesh Girhepunje</p><br />
                          &nbsp;&nbsp;&nbsp;
                          <p><AiOutlineHome size={45} style={{color:'#808080'}}/></p>
                        </Form>
                        </Navbar.Collapse>
                    </Container>
                    </Navbar>
            </>
        )
    }
}

export default Header;