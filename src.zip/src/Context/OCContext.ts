import { createContext } from "react";

interface OrderCycleContextValue
{
    ocItems:Array<any>;
    updateOCItems:any;
}

const OCContext = createContext<OrderCycleContextValue>({
    ocItems:[],
    updateOCItems:()=>{}
});

export default OCContext;