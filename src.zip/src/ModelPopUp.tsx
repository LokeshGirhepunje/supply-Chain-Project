import { useState } from 'react';
import { Col, Container, Row } from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Modal from 'react-bootstrap/Modal';

function ModelPopUPForOC() {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);









  

  return (
    <>
       <Container>
        <Row>
            <Col>
                           <center>
                           <Button variant="primary" onClick={handleShow}>
                        Launch demo modal
                    </Button>
                           </center>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modal heading</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
        
          <Container style={{backgroundColor:'#F2F2F2', borderRadius:'20px', padding:'40px 15px 40px 15px',boxShadow:' 2px 1px 3px 1px #888888'}}>
                    
               
                    <div>
    
                        <Row >
                            <Form.Group as={Col} xs={12} md={6} >
                                <Form.Label>Title</Form.Label>
                                <Form.Control disabled={true} type="text" placeholder="Enter Title" />
                            </Form.Group>
    
                            <Form.Group as={Col} xs={12} md={6}>
                                <Form.Label style={{color: 'Brown'}}>Company *</Form.Label>
                                <Form.Select >
                                    <option value={""}>Select</option>
                                
                                    
    
                                   
                                </Form.Select>
                               
                              
                            </Form.Group>                              
                        </Row>
    
    
    
                        <br></br>
                        <Row >
                            <Form.Group as={Col} xs={12} md={6} >
                                <Form.Label style={{color: 'Brown'}}>Business Unit *</Form.Label>
                                <Form.Select >
                                    <option value={""}>Select</option>
                                   
                                </Form.Select>
                                
                            </Form.Group>
    
                            <Form.Group as={Col} xs={12} md={6}>
                                <Form.Label style={{color: 'Brown'}}>Country *</Form.Label>
                                <Form.Select >
                                    <option value={""}>Select</option>
                                    
                                </Form.Select>
                               
                            </Form.Group>                              
                        </Row>
    
    
    
    
                        <br></br>
                        <Row>
                            <Form.Group as={Col} xs={12} md={6}>
                                <Form.Label style={{color: 'Brown'}}>Start Date *</Form.Label>
                                <Form.Control
                                type='date'
                                placeholder="Select Date"
                               
                                
                                ></Form.Control>  
                               
    
                                                     
                            </Form.Group>
    
                            <Form.Group as={Col} xs={12} md={6} >
                                <Form.Label  style={{color: 'Brown'}} >Expected End Date *</Form.Label>
                                <Form.Control
                                    type='date'
                                    placeholder="Select Date"
                                   
                                ></Form.Control>
                                
                            </Form.Group>
                        </Row>
    <br></br>
                        <Row>
                            <Form.Group as={Col} xs={12} md={6} >
                                <Form.Label style={{color: 'Brown'}}>Comments</Form.Label>
                                <Form.Control 
                                    as='textarea'
                                    
                                    placeholder='Enter Short Bio / Description'
                                    
                                ></Form.Control>
                               
                            </Form.Group>           
                        </Row>
    
                       
                        
                        
                    </div>    
                </Container>





          </Form>
          
        </Modal.Body>

        <center>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleClose}>
            Save Changes
          </Button>
        </Modal.Footer>
        </center>
      </Modal>
            </Col>
        </Row>
       </Container>
    </>
  );
}

export default ModelPopUPForOC;