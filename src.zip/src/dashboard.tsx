import { ColumnModel, ColumnsDirective, GridComponent,ColumnDirective,Inject,Page, Sort, Filter,Search, Toolbar } from "@syncfusion/ej2-react-grids"
import { Container } from "react-bootstrap";
import { useContext, useEffect } from "react";
import OCContext from "./Context/OCContext";
import { data1 } from "./DocumentationForGrid";


function Dashboard() {

    const { ocItems, updateOCItems } = useContext(OCContext);

    const pageSettings = { pageSize: 6 };
    const toolbarOptions = ['Search'];



    useEffect(() => {
        var a:any = document.getElementById("root");
        if(a!=null && a.nextElementSibling!=null)
        {
            a.nextElementSibling.remove();
        }
        console.log(ocItems);
    },[]);

    return(
      
        <Container>  <br /> 
            <GridComponent dataSource={[data1]} allowPaging={true} pageSettings={pageSettings} allowSorting={true} toolbar={toolbarOptions}>
                <ColumnsDirective>
                    <ColumnDirective field='OrderID' width='100' textAlign="Right" allowSorting={true} allowFiltering={true}/>
                    <ColumnDirective field='CustomerID' width='100' textAlign="Center" allowSorting={true} allowFiltering={true} />
                    <ColumnDirective field='EmployeeID' width='100' textAlign="Center"/>
                    <ColumnDirective field='OrderDate' width='100' textAlign="Center"/>
                    <ColumnDirective field='ShipName' width='100' textAlign="Center"/>
                    <ColumnDirective field='ShipCity' width='100' textAlign="Center"/>
                    <ColumnDirective field='ShipAddress' width='100' textAlign="Center"/>
                    <ColumnDirective field='ShipRegion' width='100' textAlign="Center"/>
                    <ColumnDirective field='ShipPostalCode' width='100' textAlign="Center"/>
                    <ColumnDirective field='ShipCountry' width='100' textAlign="Center"/>
                </ColumnsDirective>
                <Inject services={[Page, Sort, Filter,Search, Toolbar]}/>
            </GridComponent>
        </Container>   
    )
}

export default Dashboard;