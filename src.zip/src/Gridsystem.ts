export const OCColumns:object[]=[
    {
        field:"OC Id",
        HeaderText:"OC Id",
        backendName:"OC Id",
        width:"100",
        type: "text",
        visible:true,
        allowSorting:true,
        allowFiltering:true,
        allowSearching:true,
    },
    {
        field:"OC Name",
        HeaderText:"OC Name",
        backendName:"OC Name",
        width:"200",
        type: "Title",
        visible:true,
        allowSorting:true,
        allowFiltering:true,
        allowSearching:true,
    }
]