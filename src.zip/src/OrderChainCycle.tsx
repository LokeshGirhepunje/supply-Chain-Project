import * as React from 'react';
import { Button, Col, Container, Form, Nav, Navbar, Pagination, Row } from 'react-bootstrap';
import OCSteps from './Steps';
import 'rsuite/dist/rsuite.min.css';




interface OrderChainManagementProps {
    onRecordSubmitted: any;
}


interface SupplyStageState {
    companyItems: Array<any>
    busineesUnitItems: Array<any>
    countryItems: Array<any>
    selectedCompany: any;
    selectedBU: any;
    selectedCountry: any;
    selectedStartDAte: Date;
    selectedEndDate: Date;
    comment: string;
    usercountry: string;
    isFormValid: boolean;
    ocTitle: string;



}

const months: string[] = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export default class OrderChainCycle extends React.Component<OrderChainManagementProps, SupplyStageState>
{


    [x: string]: any;

    constructor(props: any) {
        super(props);
        this.state = {
            companyItems: [],
            busineesUnitItems: [],
            countryItems: [],
            selectedBU: '',
            selectedCompany: '',
            selectedCountry: '',
            selectedStartDAte: new Date(),
            selectedEndDate: new Date(),
            comment: "",
            usercountry: "",
            isFormValid: true,
            ocTitle: ""
        }
    }

    componentDidMount(): void {

        fetch('/Database/CompanyMaster.json', {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }
        ).then(function (response) {
            console.log(response)
            return response.json();
        })
            .then((companyData) => {
                this.setState({ companyItems: companyData.data })
                console.log(companyData);
                //setData(myJson)
            });

        fetch('/Database/BusinessUnit.json', {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }
        ).then(function (response) {
            console.log(response)
            return response.json();
        })
            .then((businessUnitsData) => {
                this.setState({ busineesUnitItems: businessUnitsData.data })
                //setData(myJson)
            });

        fetch('/Database/Countries.json', {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }
        ).then(function (response) {
            console.log(response)
            return response.json();
        })
            .then((countryData) => {
                this.setState({ countryItems: countryData.data })
                //setData(myJson)
            });
    }

    createOrderCycleTitle = () => {
        let dt = new Date();
        let tempOcTitle = `${this.state.selectedCountry}_${this.state.selectedCompany}_${this.state.selectedBU ? this.state.selectedBU.split(".")[1].trim() : ""}_${months[dt.getMonth()]} - ${dt.getFullYear()}`

        this.setState({
            ocTitle: tempOcTitle
        })
    }

    onChangeCompany = (ev: any) => {
        this.setState({
            selectedCompany: ev.target.value

        }, () => {
            this.createOrderCycleTitle();
        }
        )
    }

    onChangeBusinessUnit = (ev: any) => {
        this.setState({
            selectedBU: ev.target.value
        }, () => {
            this.createOrderCycleTitle();
        })
    }
    onChangeCountry = (ev: any) => {
        this.setState({
            selectedCountry: ev.target.value
        }, () => {
            this.createOrderCycleTitle();
        })
    }


    onChangeEndDate = (ev: any) => {
        this.setState({
            selectedEndDate: ev.target.value
        })
    }


    onChangeStartDate = (ev: any) => {
        this.setState({
            selectedStartDAte: ev.target.value
        })
    }

    FormateDate = (dt: Date) => {
        return dt.getFullYear() + "-" + this.PadNum(dt.getMonth() + 1) + "-" + this.PadNum(dt.getDate());
    }


    PadNum = (val: number) => {
        return val < 10 ? "0" + val : val;
    }

    // handleCountryName = (event:any) =>
    // {
    //     this.setState({
    //         usercountry:event.target.value
    //     })
    // }

    CreateNewOrderCycle = () => {
        if (this.isFormValid()) {
            // save the logic --- Database
            this.props.onRecordSubmitted(true, this.state);

        }
        else {
            this.setState({
                isFormValid: false
            })
        }
    }


    isFormValid = () => {
        if (
            this.state.selectedCompany === "" ||
            this.state.selectedBU === "" ||
            this.state.selectedCountry === ""
        ) {
            return false;
        }
        else {
            return true;
        }
    }

    



    render(): React.ReactNode {
        return (
                <>

                       <center style={{padding:'0px 0px 25px 0px'}}> <h1 style={{color:'green',}}>Order Chain Management System</h1></center>
            <Container fluid style={{ backgroundColor: '#F2F2F2', borderRadius: '20px', padding: '40px 15px 40px 15px', boxShadow: ' 2px 1px 3px 1px #888888' }}>


                <div>

                    <Row >
                        <Form.Group as={Col} xs={12} md={6} >
                            <Form.Label>Title</Form.Label>
                            <Form.Control disabled={true} type="text" placeholder="Enter Title" value={this.state.ocTitle} />
                        </Form.Group>

                        <Form.Group as={Col} xs={12} md={6}>
                            <Form.Label style={{ color: 'Brown' }}>Company *</Form.Label>
                            <Form.Select onChange={this.onChangeCompany}>
                                <option value={""}>Select</option>

                                {
                                    this.state.companyItems.map(item => {
                                        return <option value={item.Title}>{item.Title}</option>
                                    })
                                }


                            </Form.Select>
                            {
                                !this.state.isFormValid && this.state.selectedCompany === "" && <label style={{ color: "red" }}>Company is Required*</label>
                            }

                        </Form.Group>
                    </Row>



                    <br></br>
                    <Row >
                        <Form.Group as={Col} xs={12} md={6} >
                            <Form.Label style={{ color: 'Brown' }}>Business Unit *</Form.Label>
                            <Form.Select onChange={this.onChangeBusinessUnit}>
                                <option value={""}>Select</option>
                                {
                                    this.state.busineesUnitItems.map(item => {
                                        return <option value={item.Title}>{item.Title}</option>
                                    })
                                }
                            </Form.Select>
                            {
                                !this.state.isFormValid && this.state.selectedBU === "" && <label style={{ color: "red" }}>Business Unit is Required*</label>
                            }

                        </Form.Group>

                        <Form.Group as={Col} xs={12} md={6}>
                            <Form.Label style={{ color: 'Brown' }}>Country *</Form.Label>
                            <Form.Select onChange={this.onChangeCountry}>
                                <option value={""}>Select</option>
                                {
                                    this.state.countryItems.map(item => {
                                        return <option value={item.Title}>{item.Title}</option>
                                    })
                                }
                            </Form.Select>
                            {
                                !this.state.isFormValid && this.state.selectedCountry === "" && <label style={{ color: "red" }}>Country is Required*</label>
                            }

                        </Form.Group>
                    </Row>




                    <br></br>
                    <Row>
                        <Form.Group as={Col} xs={12} md={6}>
                            <Form.Label style={{ color: 'Brown' }}>Start Date *</Form.Label>
                            <Form.Control
                                type='date'
                                placeholder="Select Date"
                                onChange={this.onChangeStartDate}
                                value={this.FormateDate(new Date(this.state.selectedStartDAte))}
                            ></Form.Control>
                            {
                                new Date(this.state.selectedStartDAte) > new Date(this.state.selectedEndDate) ?
                                    <label style={{ color: "red" }}>Start Date Must be less than End Date.</label> : ""
                            }


                        </Form.Group>

                        <Form.Group as={Col} xs={12} md={6} >
                            <Form.Label style={{ color: 'Brown' }} >Expected End Date *</Form.Label>
                            <Form.Control
                                type='date'
                                placeholder="Select Date"
                                onChange={this.onChangeEndDate}
                                value={this.FormateDate(new Date(this.state.selectedEndDate))}
                            ></Form.Control>
                            {
                                new Date(this.state.selectedEndDate) < new Date(this.state.selectedStartDAte) ?
                                    <label style={{ color: "red" }} >End Date Must be Greater than Start Date.</label> : ""
                            }

                        </Form.Group>
                    </Row>
                    <br></br>
                    <Row>
                        <Form.Group as={Col} xs={12} md={6} >
                            <Form.Label style={{ color: 'Brown' }}>Comments</Form.Label>
                            <Form.Control
                                as='textarea'

                                placeholder='Enter Short Bio / Description'
                                value={this.state.comment}
                                onChange={(ev: any) => { this.setState({ comment: ev.target.value }) }}
                            ></Form.Control>
                            {
                                !this.state.isFormValid && this.state.comment === "" && <label style={{ color: "red" }}>Minimum 20 Words are Required*</label>
                            }

                        </Form.Group>
                    </Row>

                    <br></br>
                    <Row>
                        <center> <Form.Group as={Col} xs={12} md={4}>
                            <input type="submit" name="" id="" className='bg-danger' style={{ borderRadius: '20px', margin: '10px', padding: '5px 20px 5px 20px', color: 'white' }} onClick={this.CreateNewOrderCycle} />

                            <input type="button" name="" id="" className='bg-danger' style={{ borderRadius: '20px', margin: '10px', padding: '5px', color: 'white' }} value={'Go To Home'} />

                        </Form.Group>  </center>
                    </Row>

                </div>
            </Container>


            </>


        )
    }
}