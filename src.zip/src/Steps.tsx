import React from 'react';
import { Steps, Panel, Placeholder, ButtonGroup, Button } from 'rsuite';

import OrderChainCycle from './OrderChainCycle';
import ModelPopUPForOC from './ModelPopUp';
import Baseline from './Baseline'
import SaleForeCast from './saleForecasData';
function OCSteps()
{
  const [step, setStep] = React.useState(0);

  const [isNewOrderCycleSubmitted,setNewOrderCycleSubmitted] = React.useState(false);
  const [newOrderCycleData,setNewOrderCycleData] = React.useState(null);
  const [IsBaselineCompleted, setBaselineCompleted] = React.useState(false);
  const [IssaleForeCastCompleted, setsaleForCastCompleted] = React.useState(false);

  const onChange = (nextStep:any) => {
    setStep(nextStep < 0 ? 0 : nextStep > 3 ? 3 : nextStep);
  };

  



  const onNext = () => onChange(step + 1);
  const onPrevious = () => onChange(step - 1);

  const onRecordSubmitted = (isSubmitted:boolean,ocData:any) =>
  {
    setNewOrderCycleData(ocData);
    setNewOrderCycleSubmitted(isSubmitted)
  } 

  const isBaselineCompleted =(isCompleted:boolean)=>
  {
    setBaselineCompleted(isCompleted)
  }

    const isaleForeCastCompleted = (isComplted:boolean)=>
    {
      setsaleForCastCompleted(isComplted);
    }



  return (
    <div>
      <Steps current={step}  style={{backgroundColor:'#f2f2f2', border:'1px solid #E8E8E8', padding:'30px 10px 20px 10px', borderRadius:'10px',boxShadow:' 2px 1px 3px 1px #888888', margin:'15px 10px 0 10px'}}>
        <Steps.Item title="New Order Cycle" description="" />
        <Steps.Item title="Baseline Data" description="" />
        <Steps.Item title="Sales Forecast" description="" />
        <Steps.Item title="Closed" description="" />
      </Steps>
      <hr />
      <Panel header={`Step: ${step + 1}`}>
      {
            step===0?<OrderChainCycle onRecordSubmitted={onRecordSubmitted}></OrderChainCycle>:
            step===1?<Baseline ocData={newOrderCycleData} isBaselineCompleted={isBaselineCompleted}></Baseline>:
            step===2?<SaleForeCast ocData={newOrderCycleData} isaleForeCastCompleted={isaleForeCastCompleted}></SaleForeCast>:
            step===3?<>Closed</>:
            step===4?<>Closed</>:
            step===5?<>Closed</>:
            step===6?<>Closed</>:
            step===7?<>Closed</>:""
            
        }

      </Panel>
      <hr />
      <center>

      <ButtonGroup className=''>
        <Button onClick={onPrevious} disabled={step === 0}>
          Previous
        </Button>
        <Button onClick={onNext} disabled={step === 3 || (step===1 && !IsBaselineCompleted) || (step===2 && !IssaleForeCastCompleted) || !isNewOrderCycleSubmitted }> 





          
          Next
        </Button>
      </ButtonGroup>
      </center>
    </div>
  );
};

export default OCSteps;